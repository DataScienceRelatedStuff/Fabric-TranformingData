# Fabric notebook source

# METADATA ********************

# META {
# META   "dependencies": {
# META     "lakehouse": {
# META       "default_lakehouse": "51076d66-85d3-48d2-b913-b592f6e2aa0a",
# META       "default_lakehouse_name": "LH_Bronze",
# META       "default_lakehouse_workspace_id": "538a5c7f-9c98-493f-aac1-46d60aeb5ded"
# META     }
# META   }
# META }

# MARKDOWN ********************

# # Data Transformation


# MARKDOWN ********************

# ## Part 1) Data cleansing

# CELL ********************

# Run the query onto the 'LH_Bronze' lakehouse.

df = spark.sql("SELECT * FROM LH_BRONZE.revenue")
display(df)

# MARKDOWN ********************

# #### Duplicate data

# MARKDOWN ********************

# **Identify duplicates**

# CELL ********************

df \
    .groupby([ 'Branch_ID','Date_ID']) \
    .count() \
    .where('count > 1') \
    .show()

# MARKDOWN ********************

# **dropDuplicates()** 

# CELL ********************

# identify duplicate data
df.count()
deduped = df.dropDuplicates()
deduped.count()

print(f"Process removed {df.count() - deduped.count()} rows from the dataset" )

# MARKDOWN ********************

# **Verification** 

# CELL ********************

deduped \
    .groupby([ 'Branch_ID','Date_ID']) \
    .count() \
    .where('count > 1') \
    .show()

# MARKDOWN ********************

# #### Missing data/ nulls values 
# **Identify missing values in a column**

# CELL ********************

# option 1: using isNull() 
nulls = df.filter(df.Revenue.isNull())
display(nulls)

# option 2, using .where and col
from pyspark.sql.functions import col
nulls2 = df.where(col("Revenue").isNull())
display(nulls2)



# MARKDOWN ********************

# **Drop nulls values using dropna()**

# CELL ********************

no_nas = df.dropna(subset=['Revenue'])
print(f"Process removed {df.count() - no_nas.count()} rows from the dataset" )

# MARKDOWN ********************

# #### Type conversion + add new columns

# CELL ********************

# look @ the schema (diplay data types) 
df.printSchema()

# using cast, create a new column 
type_conv = df.withColumn('UnitsSoldConverted', df.Units_Sold.cast("string"))
type_conv.printSchema()
display(type_conv)



# MARKDOWN ********************

# #### Filter data

# CELL ********************

from pyspark.sql.functions import col

# df.filter() 
filtered_df = df.filter(col("Revenue") > 10000000)
#filtered_df = df.where(col("Revenue") > 10000000)
print(f"Proces filtered {df.count() - filtered_df.count()} rows from the dataset" )


# MARKDOWN ********************

# ## Part 2) Data enrichment
# 
# #### Add new columns (withColumn or withColumns)


# CELL ********************

# using withColumn to create new columns. 
enriched_df = df.withColumn('halfRevenue', df.Revenue/2)
display(enriched_df)

# MARKDOWN ********************

# #### Joining and merging

# CELL ********************

dealers_df = spark.sql("SELECT * FROM LH_BRONZE.dealers")
display(dealers_df)

countries_df = spark.sql("SELECT * FROM LH_BRONZE.countries")
display(countries_df)



# CELL ********************

joined_df = (
    dealers_df
        .join(countries_df, dealers_df.Country_ID == countries_df.Country_ID)
        .select(dealers_df.Dealer_ID, dealers_df.Country_ID, countries_df.Country_Name)
    )
display(joined_df)
